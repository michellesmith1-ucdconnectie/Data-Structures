package mapsql.sql.condition;

import java.util.Map;

import mapsql.sql.core.Field;
import mapsql.sql.core.SQLException;
import mapsql.sql.core.TableDescription;
import mapsql.sql.field.CHARACTER;

public class Like extends AbstractCondition {
	private String column;
	private String value;
	
	public Like(String column, String value) {
		this.column = column;
		this.value = value;
	}

	@SuppressWarnings("unchecked")
	@Override
	public boolean evaluate(TableDescription description, Map<String, String> data) throws SQLException {
		Field field = description.findField(column);
		String str=(String)field.toValue(data.get(column));
		str=str.toLowerCase();
		String pattern="";
		if(value.startsWith("%") && value.endsWith("%"))
		{
			pattern=value.replaceAll("%","").trim();
			pattern=pattern.toLowerCase();
			if(str.contains(pattern))
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		else if(value.startsWith("%"))
		{
			pattern=value.replaceAll("%","").trim();
			pattern=pattern.toLowerCase();
			if(str.endsWith(pattern))
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		else if(value.endsWith("%"))
		{
			pattern=value.replaceAll("%","").trim();
			pattern=pattern.toLowerCase();
			if(str.startsWith(pattern))
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		return false;
	}
}
