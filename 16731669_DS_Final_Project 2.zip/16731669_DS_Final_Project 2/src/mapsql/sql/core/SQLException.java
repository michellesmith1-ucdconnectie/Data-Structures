package mapsql.sql.core;

public class SQLException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3012911131809318343L;

	public SQLException(String msg) {
		super(msg);
	}

}
