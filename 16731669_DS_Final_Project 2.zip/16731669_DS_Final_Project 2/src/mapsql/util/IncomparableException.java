package mapsql.util;

public class IncomparableException extends RuntimeException {

}
