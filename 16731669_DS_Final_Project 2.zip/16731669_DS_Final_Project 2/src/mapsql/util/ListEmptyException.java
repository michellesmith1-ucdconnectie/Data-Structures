package mapsql.util;

public class ListEmptyException extends RuntimeException {

}
