package mapsql.shell.core;

public class SQLParseException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3153475704531585485L;

	public SQLParseException(String msg) {
		super(msg);
	}

}
